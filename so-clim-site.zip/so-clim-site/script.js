const navToggle = document.querySelector('.nav-toggle');
const navLinks = document.querySelector('.nav-links');
const year = document.querySelector('#year');
const bookingForm = document.querySelector('#bookingForm');

year.textContent = new Date().getFullYear();

navToggle.addEventListener('click', () => {
  navLinks.classList.toggle('open');
});

document.querySelectorAll('.nav-links a').forEach(link => {
  link.addEventListener('click', () => navLinks.classList.remove('open'));
});

bookingForm.addEventListener('submit', (event) => {
  event.preventDefault();
  const data = new FormData(bookingForm);
  const subject = encodeURIComponent('Demande de rendez-vous SO CLIM');
  const body = encodeURIComponent(`Bonjour SO CLIM,

Je souhaite prendre rendez-vous pour une recharge de clim à domicile.

Nom : ${data.get('nom')}
Téléphone : ${data.get('telephone')}
Email : ${data.get('email') || 'Non renseigné'}
Adresse : ${data.get('adresse')}
Date souhaitée : ${data.get('date')}
Heure souhaitée : ${data.get('heure')}
Message : ${data.get('message') || 'Aucun'}

Merci de me confirmer le rendez-vous.`);

  window.location.href = `mailto:contact@soclim.fr?subject=${subject}&body=${body}`;
});
